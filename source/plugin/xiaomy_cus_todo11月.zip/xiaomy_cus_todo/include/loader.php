<?php 

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'source/plugin/xiaomy_cus_todo/include/function.php';
include DISCUZ_ROOT.'source/plugin/xiaomy_cus_todo/include/Todo.class.php';